package com.example.myfirstwebservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WebServiceAppTests {

	@Test
	void contextLoads() {
	}

}
