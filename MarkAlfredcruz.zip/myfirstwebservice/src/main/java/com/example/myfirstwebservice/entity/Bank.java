package com.example.myfirstwebservice.entity;
import java.io.Serializable;
import java.math.BigDecimal;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
/**
 *Represents the bank of the Person
 *@author Group 1
 *@version 1.0
 *@since March 22, 2021
 *
 *<h1>Collaborators:</h1>
 *<ul>
 * <li>Macsterss47@github.com</li>
 * <li>ivanclemente20@github.com</li>
 * <li>Joseph1899@github.com</li>
 * <li>JesterAlcantara@github.com</li>
 * </ul>
 * <p>This is the entity for the table Bank in myfirstwebservice. </p>
 **/


@Entity
@Table(name = "Bank")
public class Bank implements Serializable {
	private static final long serialVersionUID = 1L;
	 /**
	 * DTO 
	 * 
	 */
	@ManyToOne
	@JoinColumn(name="person_id")
	private Person person; //Person id
	
	@Id
	@Column
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int id;
	/**
	 * inserting a column in bank table named accountName
	 * 
	 * */
	@Column
	private String accountName;
	/**
	 * inserting a column in bank table named bankAddress
	 * 
	 * */
	@Column
	private String bankAddress;
	
	@Column
	private String status = "ACTIVE";
	
	@Column
	private String branchName;
	
	@Column
	private BigDecimal totalBalance;

	public Person getPerson() {
		return person;
	}
	
	public void setPerson(Person person) {
		this.person = person;
	}
	/**
	  * Getter for the id field
	  * @return id
	  * */	

	public int getId() {
		return id;
	}
	/**
	  * Setter for the id field
	  * @return id
	  * */
	public void setId(int id) {
		this.id = id;
	}
	/**
	  * Getter for the accountName field
	  * @return accountName
	  * */	
	public String getAccountName() {
		return accountName;
	}
	/**
	  * Setter for the accountName field
	  * @return accountName
	  * */	
	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}
	/**
	  * Getter for the bankAddress field
	  * @return bankAddress
	  * */	
	public String getBankAddress() {
		return bankAddress;
	}
	/**
	  * Setter for the ankAddress field
	  * @return bankAddress
	  * */
	public void setBankAddress(String bankAddress) {
		this.bankAddress = bankAddress;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getBranchName() {
		return branchName;
	}

	public void setBranchName(String branchName) {
		this.branchName = branchName;
	}

	public BigDecimal getTotalBalance() {
		return totalBalance;
	}    

	public void setTotalBalance(BigDecimal totalBalance) {
		this.totalBalance = totalBalance;
	}
	
	 
}