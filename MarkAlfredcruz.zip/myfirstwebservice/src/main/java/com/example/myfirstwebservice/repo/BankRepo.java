package com.example.myfirstwebservice.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.myfirstwebservice.entity.Bank;

/**
 * This is the repository of bank table.
 * 
 * */

public interface BankRepo extends JpaRepository <Bank, Integer>{
	
}
