package com.example.myfirstwebservice.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import com.example.myfirstwebservice.entity.Person;

/**
 * This is the repository of person table.
 * 
 * */

public interface PersonRepo extends JpaRepository<Person, Integer> {

}
