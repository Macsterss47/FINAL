package com.example.myfirstwebservice.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.myfirstwebservice.entity.Bank;
import com.example.myfirstwebservice.entity.Person;
import com.example.myfirstwebservice.service.BankRecordService;
import com.example.myfirstwebservice.service.PersonRecordService;
import com.example.myfirswebservice.exception.CustomException;
/**
 * This is all the api's that you can use to access bank table.
 * 
 * */
@RestController
@CrossOrigin(origins = "*")
@RequestMapping("/bankrecord")

public class BankRestAPI {

	@Autowired
	BankRecordService bservice;
	/**
	 * This api is used to check a record in the bank table
	 * @exception CustomException
	 * */
	/// http://localhost:8080/bankrecord/bank/id
	@GetMapping("/bank/{id}")
	public Bank getBankInfo(@PathVariable("id") int id) throws Exception {
		Bank bank = bservice.getBankInfo(id);
		return bank;
		
	}
	@Autowired
	PersonRecordService personService;
	// insert record into the table
	
	/**
	 * This api is used to save a record in the bank table accepting Request body bank
	 * @exception CustomException 
	 * 
	 * */
	
	@PostMapping("/bank/{personId}")
	public Bank saveBankInfo(@PathVariable @RequestBody Bank bank) throws Exception {
		return bservice.saveBankInfo(bank);
	}
	
	//update record in to the table
	/**
	 * This api is used to update a record in bank table accepting Request body bank
	 * @exception CustomExecption
	 * */
	
	@PutMapping("/bank/{personId}")
	public Bank updateBankInfo (@RequestBody Bank bank, @PathVariable(name = "personId") int personId)  throws Exception {
		
		return bservice.updateBankInfo(bank);
	}
	

	// http://localhost:8080/bankrecord/bank?id={bank.id}
	/**
	 * 
	 * This api is used to delete a record in bank table accepting RequestParam  id
	 * 
	 * 
	 * */
	@DeleteMapping("/bank")
	public String deleteBankInfo(@RequestParam int id) {
		return bservice.deleteBankInfo(id);
	}
}